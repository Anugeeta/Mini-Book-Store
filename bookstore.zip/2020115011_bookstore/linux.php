<?php include("header.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Books</title>
    <style>
        .container{
    width: 90%;
    margin: auto;
    overflow: hidden;
   
    margin-top: 20px;
}

.container ul{
    padding: 0px;
    margin: 0px;
}


.container ul li{
    float:left;
    list-style: none;
    width:38%;
    height:500px;
    background:lightgrey;
    margin :20px 0px 20px 55px; 
    border:3px solid deeppink;
    box-sizing: border-box;
    padding:5px;
    border-radius:20px;
}
.container ul li:hover{
    opacity: 0.8;
    color:lightsalmon;
}

.container ul li .bottom{
    width: 100%;
    height:50px;
    line-height: 50px;   
    text-align: center;
    color:brown;
    font-size: 20px;
   
}
h1{
   text-align:center;
   
}
.add_to_cart{
  
  
  box-sizing: border-box;
  background-color: #98007f;
  padding:10px;
}


.add_to_cart{
  color:rgb(250, 248, 248);
}
.add_to_cart:hover{
  background-color:deeppink;
}

</style>
</head>
<body>
    <br/>
    <h1>BOOKS ON LINUX</h1>
<div class="container">
        <ul>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/RichardPetersen.jpg" alt="" width="180">
           <h5>Linux The Complete Reference </h5>
           <h5> by Richard Petersen </h5>
           <p> @ &#8377;498 &nbsp; | 1 July 2017</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Linux The Complete Reference">
        <input type="hidden" name="Price" value="498">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/AndyVickler.jpg" alt="" width="160">
           <h5>Linux:Linux Security and Administration </h5>
           <h5> by Andy Vickler</h5>
           <p> @ &#8377;399 &nbsp; |  22 March 2021</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Linux:Linux Security and Administration ">
        <input type="hidden" name="Price" value="399">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/DanielJ.Barrett.jpg" alt="" width="160">
           <h5>Linux Pocket Guide:Essential Commands</h5>
           <h5> by  Daniel J. Barrett </h5>
           <p> @ &#8377;299 &nbsp; | 1 August 2016</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Linux Pocket Guide:Essential Commands">
        <input type="hidden" name="Price" value="299">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/Love.jpg" alt="" width="180">
           <h5>Linux Kernel Development</h5>
           <h5>by Pearson </h5>
           <p> @ &#8377;399 &nbsp; | 1 January 2010</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Linux Kernel Development">
        <input type="hidden" name="Price" value="399">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/EdwardHaletky.jpg" alt="" width="180">
           <h5>Deploying LINUX on the Desktop</h5>
           <h5> by  Edward Haletky</h5>
           <p> @ &#8377;398 &nbsp; |  15 July 2005</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Deploying LINUX on the Desktop">
        <input type="hidden" name="Price" value="398">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/Syed.jpg" alt="" width="180">
           <h5>Linux The Textbook, Second Edition</h5>
           <h5> by Syed Mansoor Sarwar and Robert</h5>
           <p> @ &#8377;559 &nbsp; | 13 September 2018</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Linux The Textbook, Second Edition">
        <input type="hidden" name="Price" value="559">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/EdwardHaletky.jpg" alt="" width="180">
           <h5>Linux All-in-One for Dummies</h5>
           <h5>by Emmett Dulaney </h5>
           <p> @ &#8377;499 &nbsp; |  1 January 2018</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Linux All-in-One for Dummies">
        <input type="hidden" name="Price" value="499">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/WaleSoyinka.jpg" alt="" width="180">
           <h5>Linux Administration A Beginners Guide</h5>
           <h5> by Wale Soyinka</h5>
           <p> @ &#8377;599 &nbsp; |  1 July 2017</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Linux Administration A Beginners Guide">
        <input type="hidden" name="Price" value="599">
        </div>
</form>
        </li>
    </ul>
    </div>

</body>
</html>