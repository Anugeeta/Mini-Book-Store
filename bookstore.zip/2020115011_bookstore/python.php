<?php include("header.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Books</title>
    <style>
        .container{
    width: 90%;
    margin: auto;
    overflow: hidden;
   
    margin-top: 20px;
}

.container ul{
    padding: 0px;
    margin: 0px;
}


.container ul li{
    float:left;
    list-style: none;
    width:38%;
    height:500px;
    background:lightsalmon;
    margin :20px 0px 20px 55px; 
    border:3px solid deeppink;
    box-sizing: border-box;
    padding:5px;
    border-radius:20px;
}
.container ul li:hover{
    opacity: 0.8;
    color:lightsalmon;
}

.container ul li .bottom{
    width: 100%;
    height:50px;
    line-height: 50px;   
    text-align: center;
    color:brown;
    font-size: 20px;
   
}
h1{
   text-align:center;
   
}
.add_to_cart{
  
  
  box-sizing: border-box;
  background-color: #98007f;
  padding:10px;
}


.add_to_cart{
  color:rgb(250, 248, 248);
}
.add_to_cart:hover{
  background-color:deeppink;
}

</style>
</head>
<body>
    <br/>
    <h1>BOOKS ON PYTHON</h1>
<div class="container">
        <ul>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/HansPetterLangtangen.jpg" alt="" width="180">
           <h5>A Primer on Scientific Programming with Python</h5>
           <h5> by Hans Petter Langtangen </h5>
           <p> @ &#8377;498 &nbsp; | 12 March 2019</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="A Primer on Scientific Programming with Python">
        <input type="hidden" name="Price" value="498">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/RydhmBeri.jpg" alt="" width="200">
           <h5>Python Made Simple</h5>
           <h5> by Rydhm Beri </h5>
           <p> @ &#8377;399 &nbsp; | 21 December 2017</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Python Made Simple">
        <input type="hidden" name="Price" value="399">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/YashavantKanetkar.jpg" alt="" width="160">
           <h5>Let Us Python</h5>
           <h5> by Yashavant Kanetkar </h5>
           <p> @ &#8377;299 &nbsp; | 15 March 2018</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Let Us Python">
        <input type="hidden" name="Price" value="299">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/UDineshKumar.jpg" alt="" width="180">
           <h5>Machine Learning using Python</h5>
           <h5> by Dinesh Kumar Manaranjan Pradhan </h5>
           <p> @ &#8377;399 &nbsp; | 23 November 2019</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Machine Learning using Python">
        <input type="hidden" name="Price" value="399">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/AnjanaGupta.jpg" alt="" width="180">
           <h5>Python For Trading On Technical</h5>
           <h5> by  Anjana Gupta and Puneet Kanwar </h5>
           <p> @ &#8377;398 &nbsp; | 3 March 2019</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Python For Trading On Technical  A step towards systematic trading">
        <input type="hidden" name="Price" value="398">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/VedaangGulhane.jpg" alt="" width="180">
           <h5>The Easiest Book on Python Ever</h5>
           <h5> by Vedaang Gulhane </h5>
           <p> @ &#8377;559 &nbsp; | 12 January 2017</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="The Easiest Book on Python Ever">
        <input type="hidden" name="Price" value="559">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/LucaMassaron.jpg" alt="" width="180">
           <h5>Python for Data Science For Dummies</h5>
           <h5>by Luca Massaron John Paul Mueller </h5>
           <p> @ &#8377;499 &nbsp; | 17 December 2018</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Python for Data Science For Dummies">
        <input type="hidden" name="Price" value="499">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/EricMatthes.jpg" alt="" width="180">
           <h5>Python Crash Course</h5>
           <h5> by Eric Matthes</h5>
           <p> @ &#8377;599 &nbsp; | 7 October 2016</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Python Crash Course, 2nd Edition A Hands-On, Project-Based Introduction to Programming">
        <input type="hidden" name="Price" value="599">
        </div>
</form>
        </li>
    </ul>
    </div>

</body>
</html>