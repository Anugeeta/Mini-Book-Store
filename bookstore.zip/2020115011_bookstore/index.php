<?php include("header.php"); 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>ProBook Store</title>
    <style>
   @import url("https://fonts.googleapis.com/css?family=Open+Sans");

  .heading{
      font-size: 30px;
      color:rgb(233, 86, 86);
    
  }
  .heading h1{
    text-align:center;
   
  }
  .o{
      color:rgb(70, 64, 59);
  }
 


.container{
    width: 90%;
    margin: auto;
    overflow: hidden;
   
    margin-top: 20px;
}

.container ul{
    padding: 0px;
    margin: 0px;
}


.container ul li{
    float:left;
    list-style: none;
    width:38%;
    height:500px;
    background:lightsalmon;
    margin :20px 0px 20px 55px; 
    border:3px solid deeppink;
    box-sizing: border-box;
    padding:5px;
    border-radius:10px;
}
.container ul li:hover{
    opacity: 0.8;
    color:lightsalmon;
}

.container ul li .bottom{
    width: 100%;
    height:50px;
    line-height: 50px;   
    text-align: center;
    color:brown;
    font-size: 20px;
   
}
body{
  background-color:lightpink;
}
.add_to_cart{
  
  
  box-sizing: border-box;
  background-color: #98007f;
  padding:20px ;
  padding-left:30px;
  padding-right:30px;
}


.add_to_cart{
  color:rgb(250, 248, 248);
  padding:20px;
}
.add_to_cart:hover{
  background-color:deeppink;
  padding:20px;
}
    

* {
  margin: 0;
  padding: 0;
  box-sizing:border-box;
}

.complete{

  font-family: "Open Sans", sans-serif;
}

.container2 nav {
  width: 100%;
  height: 75px;
  background: #444759;
  border-bottom: 1px solid #3d3f50;
  position: fixed;
  top: 0;
  left: 0;
  z-index: 999;
}
/*
nav ul {
  width: 65%;
  height: 100%;
  margin: 0 auto;
  list-style: none;
  transition: all 0.5s ease;
}

nav ul li {
  width: 20%;
  float: left;
  text-align: center;
  padding: 24px 15px;
  cursor: pointer;
  color: #eee;
  font-size: 20px;
  font-weight: bold;
  text-transform: uppercase;
  transition: all 0.5s ease;

  position: relative;
}

nav ul li:hover {
  color: #ea3b50;
  box-shadow: inset 0 5px #ea3b50;
}
*/

/* sub-menu */

/*
nav ul li ul.sub-nav {
  position: absolute;
  top: 75px;
  left: 0;
  width: 100%;
  height: 250px;
  background: #444759;
  border-top: 1px solid #3d3f50;
  box-shadow: 1px 1px 2px rgba(0, 0, 0, 0.14), -1px 0px 1px rgba(0, 0, 0, 0.14);
  visibility: hidden;
  opacity: 0;
}

nav ul li ul.sub-nav li {
  color: #eee;
  font-size: 14px;
  width: 100%;
  padding: 15px 0;
}

nav ul li ul.sub-nav li:hover {
  color: #ea3b50;
  box-shadow: 0 0;
}

nav ul li:hover ul.sub-nav {
  visibility: visible;
  opacity: 1;
}
nav ul li ul.sub-nav li a{
    text-decoration: none;
    color:#eee;
}
nav ul li ul{
    text-decoration:none;
}
nav ul li ul.sub-nav li a:hover{
    color:red;
    box-shadow:0 0;
}
*/
.banner{
    position:absolute;
    top:10px;
    left:10px;
  
}
.donate{
    color:white;
    background-color: deeppink;
    font-size: 25px;
    padding:20px;
    margin-left:100px;
    margin-right:200px;
    text-align:center;
    
}
img{
  margin-left:70px;
}
.outer-footer{
   padding:20px;
    text-align: center;
    color:#ffffff;
    font-size: 18px;
    background-color: #3f3f3f;

}
.carousel {
  overflow: hidden;
  max-width: 600px;
  position: relative;
  margin-left:400px;
}

.carousel .carousel__item,
.carousel .carousel__item--hidden {
  display: none;
}

.carousel .carousel__item img {
  width: 100%;
  max-width: 600px;
  height: auto;
}

.carousel .carousel__item--visible {
  display: block;
  animation: fadeVisibility 0.5s;
}

.carousel .carousel__actions {
  display: flex;
  width: 100%;
  justify-content: space-between;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
}

.carousel .carousel__actions button {
  border-radius: 50px;
  border: 0;
  font-weight: bold;
  cursor: pointer;
  width: 40px;
  height: 40px;
  color:black;
}

.carousel .carousel__actions button#carousel__button--prev {
  margin-left: 20px;
  
}

.carousel .carousel__actions button#carousel__button--next {
  margin-right: 20px;
}

@keyframes fadeVisibility {
  0% {
    opacity: 0;
  }
  100% {
    opacity: 1;
    transform: opacity linear;
  }
}
@media screen and (max-width:1250px){
    .container ul li{
        width:40%;
        margin-left: 40px;
         
    }
}
    </style>
</head>
<body><!--
        <nav>     
           
            <ul>
           <li> <a href="index.php">Home</a></li>
           <li>Categories 
              <ul class="sub-nav">
                <li><a href="#">CGI</a></li>
                <li><a href="#">Java</a></li>
                <li><a href="#">Linux</a></li>
                <li><a href="#">PHP</a></li>
                <li><a href="#">Python</a></li>
                <li><a href="#">Shell</a></li>
              </ul>
            </li>
          
           <li><a href="mycart.php"> My Cart</a></li>
           <img src="cart.png"alt="" width="30">   
            </ul>      
        </div>
        </nav>

-->     
<div class="complete">
        <div class="heading">
            <h1 style="text-align:center;">PR<span class="o">O</span>BOOK ST<span class="o">O</span>RE</h1>
        </div>
        <br/>

 
 <br/>
 <br/>
    <div class="carousel">
      <div class="carousel__item carousel__item--visible">
        <img src="books/book2.jpg" alt="" />
      </div>
      <div class="carousel__item">
        <img src="books/book.jpg" alt=""/>
      </div>
      <div class="carousel__item">
        <img src="books/book3.jpg" alt="" />
      </div>

      <div class="carousel__actions">
        <button id="carousel__button--prev" aria-label="Previous slide"></button>
        <button id="carousel__button--next" aria-label="Next slide"></button>
      </div>
    </div>
    <br/>

       <p class="donate">A ROOM WITHOUT BOOKS IS LIKE A BODY WITHOUT A SOUL - CICERO</p>
    

    <div class="container">
        <ul>
          <li>
            <form action="manage_cart.php" method="POST">
                   <div class="bottom">
               
                      <img src="books/AllenDowney.jpg" alt="" width="180">
                      <h5>Learning with Python</h5>
                      <h5> by Allen Downey</h5>
                      <p> @ &#8377;498 &nbsp; | 12 January 2015</p>
                     
                   <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
                   <input type="hidden" name="Item_Name" value="Learning with Python">
                   <input type="hidden" name="Price" value="498">
                   </div>
           </form>
                   </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/R.NageswaraRao.jpg" alt="" width="190">
           <h5>Core Java An Integrated Approach</h5>
           <h5> by R.Nageswara Rao</h5>
           <p> @&#8377;299&nbsp; | 23 November 2018</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Core Java An Integrated Approach">
        <input type="hidden" name="Price" value="299">
        </div>
</form>
        </li>
        
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/HerbertSchildt.jpg" alt="" width="180">
           <h5>Java A Beginner's Guide</h5>
           <h5> by Herbert Schildt </h5>
           <p> @&#8377;398&nbsp; | 3 March 2015</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Java A Beginner's Guide">
        <input type="hidden" name="Price" value="398">
        </div>
</form>
        </li>

    <li>
   <form action="manage_cart.php" method="POST">
        <div class="bottom">
        <figure>
            <img src="books/HansPetterLangtangen.jpg" alt="" width="160">
         
            <h5>A Primer on Scientific Programming with Python</h5>
            <h5>by Petter Langtangen</h5>
            <p> @&#8377;359&nbsp; | 24 December 2019</p>
        </figure>
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="A Primer on Scientific Programming with Python">
        <input type="hidden" name="Price" value="359">
        </div>
</form>
       </li>  
        
  
       <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/Behrouz.jpg" alt="" width="160">
           <h5>UNIX and Shell Programming</h5>
           <h5> by Behrouz  and Richard  </h5>
           <p> @&#8377;299&nbsp; | 19 November 2003</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="UNIX and Shell Programming">
        <input type="hidden" name="Price" value="299">
        </div>
</form>
        </li>

<li>
<form action="manage_cart.php" method="POST">
        <div class="bottom">
          <figure>
            <img src="books/UDineshKumar.jpg" alt="" width="180">
         
            <h5>A Primer on Scientific Programming with Python</h5>
            <h5>by Dinesh Kumar Manaranjan Pradhan</h5>
            <p> @&#8377;499&nbsp; | 11 January 2019</p>
        </figure>
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Book1">
        <input type="hidden" name="Price" value="499">
        </div>
</form>
      </li>  
      <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/DanielBerlin.jpg" alt="" width="180">
           <h5>CGI Programming Unleashed</h5>
           <h5> by   Daniel Berlin </h5>
           <p> @&#8377;398&nbsp; |  1 July 1996</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="CGI Programming Unleashed">
        <input type="hidden" name="Price" value="398">
        </div>
</form>
        </li>
  
  
    <li>
      <form action="manage_cart.php" method="POST">
             <div class="bottom">
         
                <img src="books/StevenHolzner.jpg" alt="" width="180">
                <h5>PHP: The Complete Reference</h5>
                <h5> by Steven Holzner </h5>
                <p> @&#8377;498&nbsp; | 13 March 2018</p>
               
             <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
             <input type="hidden" name="Item_Name" value="PHP: The Complete Reference">
             <input type="hidden" name="Price" value="498">
             </div>
     </form>
             </li>
             <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/DanielJ.Barrett.jpg" alt="" width="150">
           <h5>Linux Pocket Guide:Essential Commands</h5>
           <h5> by  Daniel J. Barrett </h5>
           <p> @&#8377;299&nbsp; | 1 August 2016</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Linux Pocket Guide:Essential Commands">
        <input type="hidden" name="Price" value="299">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/JohnP.Flynt.jpg" alt="" width="180">
           <h5>Programming with PERL</h5>
           <h5> by John P.Flynt</h5>
           <p> @&#8377;559&nbsp; | 1 January 2009</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Programming with PERL">
        <input type="hidden" name="Price" value="559">
        </div>
</form>
        </li>
    </ul>
</div>
</div>
 
<br/><br/>
           <div class="outer-footer">
            Author's name: Anugeeta
            &nbsp; Date:3/7/2021 &nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;
               Copyright &copy; 2006 - 2021 Intelilinks LLC. All Rights Reserved
           </div>
  
           <script>let slidePosition = 0;
const slides = document.getElementsByClassName('carousel__item');
const totalSlides = slides.length;

document.
  getElementById('carousel__button--next')
  .addEventListener("click", function() {
    moveToNextSlide();
  });
document.
  getElementById('carousel__button--prev')
  .addEventListener("click", function() {
    moveToPrevSlide();
  });

function updateSlidePosition() {
  for (let slide of slides) {
    slide.classList.remove('carousel__item--visible');
    slide.classList.add('carousel__item--hidden');
  }

  slides[slidePosition].classList.add('carousel__item--visible');
}

function moveToNextSlide() {
  if (slidePosition === totalSlides - 1) {
    slidePosition = 0;
  } else {
    slidePosition++;
  }

  updateSlidePosition();
}

function moveToPrevSlide() {
  if (slidePosition === 0) {
    slidePosition = totalSlides - 1;
  } else {
    slidePosition--;
  }

  updateSlidePosition();
}
</script>
</body>
</html>
