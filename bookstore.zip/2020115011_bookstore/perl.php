<?php include("header.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Books</title>
    <style>
        .container{
    width: 90%;
    margin: auto;
    overflow: hidden;
   
    margin-top: 20px;
}

.container ul{
    padding: 0px;
    margin: 0px;
}


.container ul li{
    float:left;
    list-style: none;
    width:38%;
    height:500px;
    background:lightsteelblue;
    margin :20px 0px 20px 55px; 
    border:3px solid deeppink;
    box-sizing: border-box;
    padding:5px;
    border-radius:20px;
}
.container ul li:hover{
    opacity: 0.8;
    color:lightsalmon;
}

.container ul li .bottom{
    width: 100%;
    height:50px;
    line-height: 50px;   
    text-align: center;
    color:brown;
    font-size: 20px;
   
}
h1{
   text-align:center;
   
}
.add_to_cart{
  
  
  box-sizing: border-box;
  background-color: #98007f;
  padding:10px;
}


.add_to_cart{
  color:rgb(250, 248, 248);
}
.add_to_cart:hover{
  background-color:deeppink;
}

</style>
</head>
<body>
    <br/>
    <h1>BOOKS ON PERL</h1>
<div class="container">
        <ul>
   
       
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/MartinBrown.jpg" alt="" width="160">
           <h5>Perl:The Complete Reference </h5>
           <h5> by Martin Brown</h5>
           <p> @ &#8377;399 &nbsp; |  22 March 2001</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Perl:The Complete Reference">
        <input type="hidden" name="Price" value="399">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/NexcodPublishing.jpg" alt="" width="160">
           <h5>Perl:PERL Programming for Beginners </h5>
           <h5> by Nexcod Publishing </h5>
           <p> @ &#8377;299 &nbsp; | 6 August 2019</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Perl:PERL Programming for Beginners">
        <input type="hidden" name="Price" value="299">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/TomChristiansen.jpg" alt="" width="180">
           <h5>Programming Perl Unmatched power for text processing & scripting</h5>
           <h5>by Tom Christiansen </h5>
           <p> @ &#8377;399 &nbsp; | 19 March 2012</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Programming Perl Unmatched power for text processing & scripting">
        <input type="hidden" name="Price" value="399">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/LarryWall.jpg" alt="" width="180">
           <h5>Programming Perl, 3rd Edition</h5>
           <h5> by  Larry Wall and Tom Christiansen</h5>
           <p> @ &#8377;398 &nbsp; |   1 Jaunary 2000</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Programming Perl, 3rd Edition">
        <input type="hidden" name="Price" value="398">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/JohnP.Flynt.jpg" alt="" width="180">
           <h5>Programming with PERL</h5>
           <h5> by John P.Flynt</h5>
           <p> @ &#8377;559 &nbsp; | 1 January 2009</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Programming with PERL">
        <input type="hidden" name="Price" value="559">
        </div>
</form>
        </li>
     
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/StevenHolzner.jpg" alt="" width="180">
           <h5>Perl Black Book</h5>
           <h5> by Steven Holzner</h5>
           <p> @ &#8377;599 &nbsp; |  18 December 2019</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Perl Black Book">
        <input type="hidden" name="Price" value="599">
        </div>
</form>
        </li>
    </ul>
    </div>

</body>
</html>