<?php include("header.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Books</title>
    <style>
        .container{
    width: 90%;
    margin: auto;
    overflow: hidden;
   
    margin-top: 20px;
}

.container ul{
    padding: 0px;
    margin: 0px;
}


.container ul li{
    float:left;
    list-style: none;
    width:38%;
    height:500px;
    background:rgb(145, 235, 241);
    margin :20px 0px 20px 55px; 
    border:3px solid deeppink;
    box-sizing: border-box;
    padding:5px;
    border-radius:20px;
}
.container ul li:hover{
    opacity: 0.8;
    color:lightsalmon;
}

.container ul li .bottom{
    width: 100%;
    height:50px;
    line-height: 50px;   
    text-align: center;
    color:brown;
    font-size: 20px;
   
}
h1{
   text-align:center;
   
}
.add_to_cart{
  
  
  box-sizing: border-box;
  background-color: #98007f;
  padding:10px;
}


.add_to_cart{
  color:rgb(250, 248, 248);
}
.add_to_cart:hover{
  background-color:deeppink;
}

</style>
</head>
<body>
    <br/>
    <h1>BOOKS ON CGI</h1>
<div class="container">
        <ul>
   
       
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/MarkFelton.jpg" alt="" width="160">
           <h5>CGI Internet Programming in C++ and C  </h5>
           <h5> by Mark Felton</h5>
           <p> @ &#8377;399 &nbsp; | 28 March 1997</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="CGI Internet Programming in C++ and C ">
        <input type="hidden" name="Price" value="399">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/Jacqueline.jpg" alt="" width="160">
           <h5>Cgi Programming 101:Perl for the World Wide Web </h5>
           <h5> by Jacqueline D.Hamilton </h5>
           <p> @ &#8377;299 &nbsp; | 14 April 2004</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Cgi Programming 101:Perl for the World Wide Web">
        <input type="hidden" name="Price" value="299">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/ThomasBoutell.jpg" alt="" width="180">
           <h5>CGI Programming in C and Perl </h5>
           <h5>by Thomas Boutell  </h5>
           <p> @ &#8377;399 &nbsp; | 19 April 1996</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="CGI Programming in C and Perl ">
        <input type="hidden" name="Price" value="399">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/DanielBerlin.jpg" alt="" width="180">
           <h5>CGI Programming Unleashed</h5>
           <h5> by   Daniel Berlin </h5>
           <p> @ &#8377;398 &nbsp; |  1 July 1996</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="CGI Programming Unleashed">
        <input type="hidden" name="Price" value="398">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/Scott.jpg" alt="" width="180">
           <h5>CGI Programming With Perl</h5>
           <h5> by Scott Guelich and Shishir Gundavaram</h5>
           <p> @ &#8377;559 &nbsp; | 14 January 2006</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="CGI Programming With Perl">
        <input type="hidden" name="Price" value="559">
        </div>
</form>
        </li>
     
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/OferLaor.jpg" alt="" width="180">
           <h5>CGI Programming with Visual Basic 5 </h5>
           <h5> by Ofer Laor</h5>
           <p> @ &#8377;599 &nbsp; |  18 December 1997</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="CGI Programming with Visual Basic 5 ">
        <input type="hidden" name="Price" value="599">
        </div>
</form>
        </li>
    </ul>
    </div>

</body>
</html>