<?php
require("admin-connection.php");
include('header.php');


?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Admin Panel</title>
	  
<style>
	@import url('https://fonts.googleapis.com/css?family=Montserrat|Open+Sans|Roboto');

	.panel {
  background-color:black;
  height: 80px;
  width: 90%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 5%;

  position: relative;
  color:white;
}

.Logout{
  color:rgb(250, 248, 248);
  color:white;
  font-size:20px;
  cursor:pointer;
  background-color:lightpink;
 margin-left:800px;
 top:1%;
}
.Logout:hover{
  background-color:purple ;
}

/*
.filter{
 position: absolute;
 left: 0;
 top: 0;
 bottom: 0;
 right: 0;
 z-index: 1;
 
 
 background: rgb(233,76,161);
background: -moz-linear-gradient(90deg, rgba(233,76,161,1) 0%, rgba(199,74,233,1) 100%);
background: -webkit-linear-gradient(90deg, rgba(233,76,161,1) 0%, rgba(199,74,233,1) 100%);
background: linear-gradient(90deg, rgba(233,76,161,1) 0%, rgba(199,74,233,1) 100%);


filter: progid:DXImageTransform.Microsoft.gradient(startColorstr="#e94ca1",endColorstr="#c74ae9",GradientType=1);
opacity: .7;
}
table{
 position: relative;
 z-index: 2;
 left: 50%;
 top: 50%;
 transform: translate(-50%,-50%);
 width: 50%; 
 border-collapse: collapse;
 border-spacing: 0;
 box-shadow: 0 2px 15px rgba(64,64,64,.7);
 border-radius: 12px 12px 0 0;
 overflow: hidden;

}
td , th{
 padding: 15px 25px;
 text-align: center;
 

}
th{
 background-color: #ba68c8;
 color: #fafafa;
 font-family: 'Open Sans',Sans-serif;
 font-weight: 100;
 text-transform: uppercase;

}
tr{
 width: 100%;
 background-color: #fafafa;
 font-family: 'Montserrat', sans-serif;
}
tr:nth-child(even){
 background-color: #eeeeee;
}
*{
	margin: 0;
	outline:0;
	padding:0;
}
*/

.content-table {
  border-collapse: collapse;
  margin: 25px 0;
  font-size: 1em;
  min-width: 400px;
  border-radius: 5px 5px 0 0;
  overflow: hidden;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
  margin-left:500px;
  background-color:lightgrey;
}

.content-table thead tr {
  background-color: purple;
  color: white;
  text-align: left;
  font-weight: bold;
}

.content-table th,
.content-table td {
  padding: 15px 50px;
}

.content-table tbody tr {
  border-bottom: 1px solid purple;
}

.content-table tbody tr:nth-of-type(even) {
  background-color: none;
}

.content-table tbody tr:last-of-type {
  border-bottom: 2px solid purple;
}

.content-table tbody tr.active-row {
  font-weight: bold;
  color: purple;
}


</style>
</head>
<body>



<div class="filter">

       <h1 style="text-align:center; color:purple">ORDER DETAILS</h1>
</div>
<table class="content-table">
<thead>
<tr>

<th>Name of the Book</th>


<th>Price</th>
<th>Quantity</th>




</tr>

</thead>
<tbody>
<?php

 
$con=mysqli_connect("localhost","root","","testing");
if(mysqli_connect_error())
{
    echo"Cannot connect to database";
    exit();
}



 $query="SELECT * FROM `order_manager`";
$user_result=mysqli_query($con,$query);


/*
while($user_fetch=mysqli_fetch_assoc($user_result))
{
    echo"




 <tr>

<td>$user_fetch[Order_Id]</td>

<td>$user_fetch[Full_Name]</td>



<td>

<table>
<thead>
<tr>

<th>Item Name</th>

<th>Price</th>

<th>Quantity</th>

</tr>
<thead>
<tbody>

";

*/

$order_query="SELECT * FROM `user_orders2` ";
$order_result=mysqli_query($con,$order_query);
while($order_fetch=mysqli_fetch_assoc($order_result))
{
    
    echo"
  <tbody>
    <tr>
    
    <td>$order_fetch[Item_Name]</td>
   
    <td>$order_fetch[Price]</td>
     <td>$order_fetch[Quantity]</td>
    </tr>
    ";

}
echo"


</tbody>
</table>

</td>
</tr>

";


?>


<?php 
	if(isset($_POST['Logout']))
	{
		session_destroy();
		header('location:admin-login.php');
	}
	
	?>

</body>
</html>