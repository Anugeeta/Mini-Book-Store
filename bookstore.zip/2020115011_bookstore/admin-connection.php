

    <?php 

    
/*
$host="localhost";
$user="root";
$password="";
$db="testing";

$con=mysqli_connect($host,$user,$password);
mysqli_select_db($db);

if(isset($_POST['Login'])){
    
    $uname=$_POST['Admin_Name'];
    $password=$_POST['Admin_Password'];
    
    $sql="select * from admin_login where Admin_Name='".$uname."'AND Admin_Password='".$password."' limit 1";
    
    $result=mysqli_query($sql);
    if(mysqli_num_rows($result)==1){
        echo " You Have Successfully Logged in";
        exit();
    }
    else{
        echo " You Have Entered Incorrect Password";
        exit();
    }
        
}

*/


$con=mysqli_connect("localhost","root","","testing");
if(mysqli_connect_error())
{
    echo"Cannot connect to database";
    exit();
}









?>
</body>
</html>