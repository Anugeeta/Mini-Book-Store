<?php session_start(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <title>ProBook Store</title>
    <style>
        {
            background-color: lightsalmon;
        }
           .navl1{
        flex:1;
      
         background-color: rgb(253, 110, 53);/*rgb(74, 74, 117);*/
         text-align: end;
      margin-top:none;
     
     
     }
     .navl1 ul li{
         list-style: none;
         display: inline-block;
         padding:6px 10px;
         position:relative;
 
     
     }
     .navl1 ul li a{
         color: #ffffff;
         font-size: 18px;
         font-family: sans-serif;
         text-decoration:none;
         
         padding:10px 10px;
         padding-top: none;
     
     }
     .navl1 ul li a:hover{
        font-size:18px;
         background-color:lightsalmon;/*rgb(96, 142, 211);*/
         border:1px solid white;
     }
     .heading{
      font-size: 30px;
      color:deeppink;
    
  }
  .heading h1{
    text-align:center;
    color:deeppink;
   
  }
  .o{
      color:rgb(70, 64, 59);
  }
  .dropdown-menu {
  display: none;
}

.navl ul li:hover .dropdown-menu {
  display: block;
  position: absolute;
  left: 0;
  top: 100%;
  background-color:deeppink;
}

.navl ul li:hover .dropdown-menu ul {
  display: block;
  margin: 10px;
}

.navl ul li:hover .dropdown-menu ul li {
  width: 150px;
  padding: 10px;
}

body{
  background-color:lightpink;

}
.Logout{
  color:rgb(250, 248, 248);
  color:white;
  font-size:20px;
  cursor:pointer;
  background-color:purple;
 margin-left:900px;
 padding:5px;
 
}
.Logout:hover{
  background-color:lightpink;
}


}
.navl {
  background-color:blue;
  height: 80px;
  width: 100%;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 5%;
   color:white;
  position: relative;
}

.navl ul {
  list-style: none;
  display: flex;
  background-color:deeppink;
}

.navl ul li {
  /* width: 120px; */
  padding: 10px 30px;
 text-align: center; 

  position: relative;
}

.navl ul li a {
  font-size: 20px;
  color: black;
  text-decoration: none;

  transition: all 0.3s;
}

.navl ul li a:hover {
  color: pink;

}
 *{
    margin: 0;
  padding: 0;
  box-sizing: border-box;
 }
.image{
  padding:0;
}
 
     </style>
</head>
<body>
        <nav>     
            <div class="navl">
            <ul>
           <li> <a href="index.php">Home</a></li>
           <li><a href="#">Categories</a>
          <div class="dropdown-menu">
              <ul>
              
                <li><a href="cgi.php">CGI</a></li>
                <li><a href="java.php">Java</a></li>
                <li><a href="linux.php">Linux</a></li>
                <li><a href="perl.php">Perl</a></li>
                <li><a href="PHP.php">PHP</a></li>
                <li><a href="python.php">Python</a></li>
                <li><a href="shell.php">Shell</a></li>
              </ul>
</div>
            </li>
           <?php 
           $count=0;
           if(isset($_SESSION['cart']))
           {
               $count=count($_SESSION['cart']);
           }
           ?>
           <li><a href="mycart.php"> My Cart (<?php echo $count; ?>)</a></li>
        
              
<form action="admin-login.php" method="POST">
<button type="submit" name="Logout" CLASS="Logout">LOG OUT</button>
</form>  
</ul>  
            
        </div>
  
        </nav>
     
        </body>
        </html>