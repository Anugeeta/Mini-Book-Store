
<?php require("admin-connection.php"); 



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   
    <link rel="stylesheet"  href="css/font-awesome.min.css">
    <title>Admin Login</title>
    <style>
    body{
	margin: 0 auto;
	background-image: url("../image/technology.jpg");
	background-repeat: no-repeat;
	background-size: 100% 720px;
}
body{
                margin:0;
                padding:0;
                background: url("books/book5.jpg");
                background-size: cover;
                background-position: center;
                font-family: sans-serif;
            
            }

.container{
	width: 500px;
	height: 450px;
	text-align: center;
	margin: 0 auto;
	background-color: rgba(44, 62, 80,0.7);
	margin-top: 160px;
}

.container img{
	width: 150px;
	height: 150px;
	margin-top: -60px;
}

input[type="text"],input[type="password"]{
	margin-top: 30px;
	height: 45px;
	width: 300px;
	font-size: 18px;
	margin-bottom: 20px;
	background-color: #fff;
	padding-left: 40px;
}

.form-input::before{
	
	font-family: "FontAwesome";
	padding-left: 07px;
	padding-top: 40px;
	position: absolute;
	font-size: 35px;
	color: #2980b9; 
}

.form-input:nth-child(2)::before{
	
}

.btn-login{
	padding: 15px 25px;
	border: none;
	background-color: #27ae60;
	color: #fff;
}

    </style>
</head>
<body>
	<BR/><BR/>
	<h1 STYLE="TEXT-ALIGN:CENTER;FONT-SIZE:50PX;COLOR:WHITE;">PROBOOKSTORE-LOGIN</h1>
	<div class="container">
	<img src="books/login.png" alt="" width="800">
		<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) ?>" method="POST">
			<div class="form-input">
				<input type="text" name="AdminName" placeholder="Enter the User Name"/>	
			</div>
			<div class="form-input">
				<input type="password" name="AdminPass" placeholder="Password"/>
			</div>
			<button type="submit" name="Login" class="btn-login">LOGIN</button>
		</form>
	</div>



<?php

function input_filter($data)
{
    $data=trim($data);
    $data=stripslashes($data);
    $data=htmlspecialchars($data);
    return $data;
}

    
if(isset($_POST['Login']))
{
   
   $AdminName=input_filter($_POST['AdminName']);
   $AdminPass=input_filter($_POST['AdminPass']);

   $AdminName=mysqli_real_escape_string($con,$AdminName);
   $AdminPass=mysqli_real_escape_string($con,$AdminPass);

  $query="SELECT * FROM `admin` WHERE `Admin_Name`=? AND `Admin_Password`=?";
  if($stmt=mysqli_prepare($con,$query))
  {
    mysqli_stmt_bind_param($stmt,"ss",$AdminName,$AdminPass);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    if(mysqli_stmt_num_rows($stmt)==1)
    {
        session_start();
        $_SESSION['AdminLoginId']=$AdminName;
        header("location:index.php");
    }
	else{
        echo "<script> alert('Invalid Admin Name or Password');</script>";
    }

    mysqli_stmt_close($stmt);
  }
  else{
    echo "<script> alert('SQL Cannot be prepared');</script>";
  }


}


?>
    </body>
    </html>