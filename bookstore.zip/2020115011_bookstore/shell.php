<?php include("header.php"); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Python Books</title>
    <style>
        .container{
    width: 90%;
    margin: auto;
    overflow: hidden;
   
    margin-top: 20px;
}

.container ul{
    padding: 0px;
    margin: 0px;
}


.container ul li{
    float:left;
    list-style: none;
    width:38%;
    height:500px;
    background:lightgoldenrodyellow;
    margin :20px 0px 20px 55px; 
    border:3px solid deeppink;
    box-sizing: border-box;
    padding:5px;
    border-radius:20px;
}
.container ul li:hover{
    opacity: 0.8;
    color:lightsalmon;
}

.container ul li .bottom{
    width: 100%;
    height:50px;
    line-height: 50px;   
    text-align: center;
    color:brown;
    font-size: 20px;
   
}
h1{
   text-align:center;
   
}
.add_to_cart{
  
  
  box-sizing: border-box;
  background-color: #98007f;
  padding:10px;
}


.add_to_cart{
  color:rgb(250, 248, 248);
}
.add_to_cart:hover{
  background-color:deeppink;
}

</style>
</head>
<body>
    <br/>
    <h1>BOOKS ON SHELL</h1>
<div class="container">
        <ul>
   
       
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/BintuHarwani.jpg" alt="" width="160">
           <h5>UNIX & Shell Programming </h5>
           <h5> by Bintu Harwani</h5>
           <p> @ &#8377;399 &nbsp; |  24 October 2013</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="UNIX & Shell Programming">
        <input type="hidden" name="Price" value="399">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/Behrouz.jpg" alt="" width="160">
           <h5>UNIX and Shell Programming</h5>
           <h5> by Behrouz  and Richard  </h5>
           <p> @ &#8377;299 &nbsp; | 19 November 2003</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="UNIX and Shell Programming">
        <input type="hidden" name="Price" value="299">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/AnoopChaturvedi.jpg" alt="" width="180">
           <h5>Unix and Shell Programming</h5>
           <h5>by Anoop Chaturvedi and B.L. Rai </h5>
           <p> @ &#8377;399 &nbsp; | 19 March 2011</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Unix and Shell Programming">
        <input type="hidden" name="Price" value="399">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/YashavantKanetkar11.jpg" alt="" width="180">
           <h5>Unix Shell Programming</h5>
           <h5> by Yashavant Kanetkar</h5>
           <p> @ &#8377;398 &nbsp; |   11 August 2003</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Unix Shell Programming">
        <input type="hidden" name="Price" value="398">
        </div>
</form>
        </li>
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/CameronNewham.jpg" alt="" width="180">
           <h5>Unix Shell Programming, Third Edition</h5>
           <h5> by Cameron Newham</h5>
           <p> @ &#8377;559 &nbsp; | 1 January 2009</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Unix Shell Programming, Third Edition">
        <input type="hidden" name="Price" value="559">
        </div>
</form>
        </li>
     
        <li>
 <form action="manage_cart.php" method="POST">
        <div class="bottom">
    
           <img src="books/Stephen.jpg" alt="" width="180">
           <h5>Shell Programming in Unix, Linux and OS X</h5>
           <h5> by Stephen G.Kochan and Patrick Wood</h5>
           <p> @ &#8377;599 &nbsp; |  18 December 2016</p>
          
        <button type="submit" name="add_to_cart" class="add_to_cart">Add to Cart</button>
        <input type="hidden" name="Item_Name" value="Shell Programming in Unix, Linux and OS X">
        <input type="hidden" name="Price" value="599">
        </div>
</form>
        </li>
    </ul>
    </div>

</body>
</html>