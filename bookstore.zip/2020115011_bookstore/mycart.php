<?php include('header.php'); 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ProBook Store</title>
    <style>
       *{margin: 0; padding: 0;}
        body{background: #ecf1f4; font-family: sans-serif;}
        
        .form-wrap{ width: 320px; background: #3e3d3d; padding: 40px 20px; box-sizing: border-box; position: fixed; left: 50%; top: 50%; transform: translate(-50%, -50%);}
        h1{text-align: center; color: #fff; font-weight: normal; margin-bottom: 20px;}
        
        .cash-card input{width: 20%; background: none; border: 1px solid #fff; border-radius: 3px; padding: 6px 15px; box-sizing: border-box; margin-bottom: 20px; font-size: 16px; color: black;}
        
        input[type="button"]{ background: #bac675; border: 0; cursor: pointer; color: #3e3d3d;}
        input[type="button"]:hover{ background: #a4b15c; transition: .6s;}
        
        ::placeholder{color: #fff;}
    
      /*
      .table1{
             text-align: center;
             font-size:20px;
             margin-left:500px;

      }
      .table-head,.table_body{
        text-align:center;
        margin-left:500px;

      }
      .table-head{
        background-color:white;
        border:1px solid grey;
      }
*/

.content-table {
  border-collapse: collapse;
  margin: 25px 0;
  font-size: 1em;
  min-width: 400px;
  border-radius: 5px 5px 0 0;
  overflow: hidden;
  box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
  margin-left:100px;
}

.content-table thead tr {
  background-color: saddlebrown;
  color: white;
  text-align: left;
  font-weight: bold;
}

.content-table th,
.content-table td {
  padding: 15px 50px;
}

.content-table tbody tr {
  border-bottom: 1px solid brown;
}

.content-table tbody tr:nth-of-type(even) {
  background-color: none;
}

.content-table tbody tr:last-of-type {
  border-bottom: 2px solid brown;
}

.content-table tbody tr.active-row {
  font-weight: bold;
  color: brown;
}


 
h1{text-align:center;
    color: black;
    font-size:40px;

}
.btn:hover{
  outline-color: darkred;
  color:white;
  cursor:pointer;
  background-color:darkred;

}
.btn{
  background-color: orangered;
  color:white;
  padding:8px;
 
}
.purchase{
  margin-left:600px;
  box-sizing: border-box;
  background-color: #98007f;
  padding:10px;
}


.purchase{
  color:rgb(250, 248, 248);
}
.purchase:hover{
  background-color: deeppink;
}

.total h3,.total h5{
  margin-left:600px;
  font-size:25px;
}

.cash-card input{
   margin-left:600px;
  color:saddlebrown;
  font-weight:bold;
}
.cash-card{
  
  color:white;
}

.total{

padding-left:10px;
  border-radius: 5px 5px 0 0;

}
body{
  background-color:lightpink;
}
.navl ul{
  background-color:lightcoral;

}
.cash input{
   margin-left:600px;
  color:saddlebrown;
  font-weight:bold;
}
.label1{
  color:white;
  margin-left:-150px;
  font-size:20px;
}
  </style>
</head>
<body>
  <h1>MY CART</h1>
  <table class="content-table">

    <thead>
    <tr>
      <th>Serial No.</th>
      <th>Book Name</th>
      <th>Book Price</th>
      <th>Quantity</th>
      <th>Total</th>
      <th></th>
     
   </tr>
    </thead>

    <tbody>
      <?php 
   
      if(isset($_SESSION['cart']))
      {
      foreach($_SESSION['cart'] as $key => $value)
      { $sr=$key+1;
        
        echo"
        <tr class='active-row'>
        <td>$sr</td>
        <td>$value[Item_Name]</td>
        <td>$value[Price]<input type='hidden' class='iprice' value='$value[Price]'></td>
        <td>
        <form action='manage_cart.php' method='post'>
        <input class='iquantity' name='Mod_Quantity'  onchange='subtotal()' type='number' value='$value[Quantity]' min='1'>
        <input type='hidden' name='Item_Name' value='$value[Item_Name]'>
        </form>
        </td>
        <td class='itotal'></td>
        <td>
        <form action='manage_cart.php' method='POST'>
        <button name='remove_btn' class='btn'>REMOVE</button>
        <input type='hidden' name='Item_Name' value='$value[Item_Name]'>
        </form>
        </td>
        </tr>
        ";
      } 
    }
      ?>
    
    </tbody>
    </table>
    
  <div class="total">

   <h3>Grand Total:</h3>
   <h5 id="gtotal"></h5>
   <br/>
  <?php 
  if(isset($_SESSION['cart']) && count($_SESSION['cart'])>0)
  {
  ?>
  <!--
    <div class="form-wrap">
        
    <form action='order_details.php' method='POST'>
        
            
    <input type='text' name='Full_Name' placeholder='Full Name'>
   
    <input type='number' name='Phone_No'  placeholder='Phone Number'>
    <input type='text' name='Address'  placeholder='Address'>
   
    <input type='radio' name='Pay_Mode' value='COD' placeholder='Cash On Delivery'>

         -->
    
  <form action='card_payment.php' method='POST'>
    <div class='cash-card'>
   
    <input type='text' name='Full_Name' class='cash' placeholder='Full Name' required><br/>
    
    <input type='number' name='Phone_No' class='cash' placeholder='Phone Number' required><br/>
    <input type='text' name='Address' class='cash' placeholder='Address' required><br/>
   <input type='radio' name='Pay_Mode' value='CC/DC'> <span class="label1"><label>Credit/Debit Card</label></span><br/>

   
    </div>
 
  <button class="purchase" name="purchase">Next</button>
 
  </form>
    
    </div>
   <br/><br/>
  </form>
  <?php 
  }
  ?>
</div>

<script>
  var gt=0;
  var iprice=document.getElementsByClassName('iprice');
  var iquantity=document.getElementsByClassName('iquantity');
  var itotal=document.getElementsByClassName('itotal')
  var gtotal=document.getElementById('gtotal');
  function subtotal()
  {gt=0;
    for(i=0;i<iprice.length;i++)
    {
      itotal[i].innerText=(iprice[i].value)*(iquantity[i].value);
      gt=gt+(iprice[i].value)*(iquantity[i].value);
    }
    gtotal.innerText=gt;
  }
  subtotal();
  
  </script>
</body>
</html>